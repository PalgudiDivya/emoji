import React from 'react';
import { Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

const MoodStats = ({ moodHistory }) => {
  const moodCounts = moodHistory.reduce((acc, entry) => {
    acc[entry.mood.label] = (acc[entry.mood.label] || 0) + 1;
    return acc;
  }, {});

  const data = {
    labels: Object.keys(moodCounts),
    datasets: [
      {
        data: Object.values(moodCounts),
        backgroundColor: [
          '#FBBF24', // yellow-400
          '#60A5FA', // blue-400
          '#F87171', // red-400
          '#34D399', // green-400
          '#A78BFA', // purple-400
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
      },
    },
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-semibold mb-4">Mood Statistics</h2>
      <div className="h-64">
        <Pie data={data} options={options} />
      </div>
    </div>
  );
};

export default MoodStats; 