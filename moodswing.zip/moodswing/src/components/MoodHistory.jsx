import React from 'react';
import { format } from 'date-fns';

const MoodHistory = ({ moodHistory }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-semibold mb-4">Mood History</h2>
      <div className="space-y-4">
        {moodHistory.map((entry, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center space-x-3">
              <span className="text-2xl">{entry.mood.emoji}</span>
              <div>
                <p className="font-medium">{entry.mood.label}</p>
                <p className="text-sm text-gray-500">
                  {format(new Date(entry.date), 'MMM dd, yyyy')}
                </p>
              </div>
            </div>
            {entry.note && (
              <p className="text-sm text-gray-600 max-w-xs truncate">
                {entry.note}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MoodHistory; 