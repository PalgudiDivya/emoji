import React from 'react';

const moods = [
  { id: 'happy', label: 'Happy', emoji: '😊', color: 'bg-yellow-400' },
  { id: 'sad', label: 'Sad', emoji: '😔', color: 'bg-blue-400' },
  { id: 'neutral', label: 'Neutral', emoji: '😐', color: 'bg-gray-400' },
  { id: 'angry', label: 'Angry', emoji: '😡', color: 'bg-red-400' },
  { id: 'excited', label: 'Excited', emoji: '🤩', color: 'bg-purple-400' },
  { id: 'sleepy', label: 'Sleepy', emoji: '😴', color: 'bg-indigo-400' },
  { id: 'sick', label: 'Sick', emoji: '🤢', color: 'bg-green-400' },
  { id: 'scared', label: 'Scared', emoji: '😨', color: 'bg-orange-400' },
  { id: 'cry', label: 'Cry', emoji: '😢', color: 'bg-blue-500' },
  { id: 'relaxed', label: 'Relaxed', emoji: '😌', color: 'bg-teal-400' },
];

const MoodSelector = ({ onSelectMood }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
      {moods.map((mood) => (
        <button
          key={mood.id}
          onClick={() => onSelectMood(mood)}
          className={`${mood.color} p-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex flex-col items-center transform hover:scale-105`}
        >
          <span className="text-4xl mb-2">{mood.emoji}</span>
          <span className="text-white font-semibold">{mood.label}</span>
        </button>
      ))}
    </div>
  );
};

export default MoodSelector; 