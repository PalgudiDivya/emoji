import React, { useState, useEffect } from 'react';
import MoodSelector from './components/MoodSelector';
import MoodHistory from './components/MoodHistory';
import MoodStats from './components/MoodStats';
import NoteInput from './components/NoteInput';

function App() {
  const [moodHistory, setMoodHistory] = useState(() => {
    const saved = localStorage.getItem('moodHistory');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
  }, [moodHistory]);

  const handleSelectMood = (mood) => {
    const newEntry = {
      mood,
      date: new Date().toISOString(),
      note: '',
    };
    setMoodHistory([newEntry, ...moodHistory]);
  };

  const handleAddNote = (note) => {
    if (moodHistory.length > 0) {
      const updatedHistory = [...moodHistory];
      updatedHistory[0] = { ...updatedHistory[0], note };
      setMoodHistory(updatedHistory);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">Mood Swing</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <MoodSelector onSelectMood={handleSelectMood} />
            <NoteInput onAddNote={handleAddNote} />
          </div>
          
          <div className="space-y-8">
            <MoodStats moodHistory={moodHistory} />
            <MoodHistory moodHistory={moodHistory} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App; 